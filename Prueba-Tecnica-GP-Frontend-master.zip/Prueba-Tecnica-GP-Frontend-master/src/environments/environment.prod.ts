export const environment = {
  production: true,
  apiBaseUrl: 'http://apipruebatecnica.somee.com/api'  
};
